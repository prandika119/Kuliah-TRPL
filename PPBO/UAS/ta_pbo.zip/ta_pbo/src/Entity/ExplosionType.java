package Entity;

public enum ExplosionType
{
    STRAY,
    MOST,
    PLAYER
}